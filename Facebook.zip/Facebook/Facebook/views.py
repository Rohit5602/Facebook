from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render,redirect
from userdata.models import UserData


# def Temp(request):
#         return render(request,"Home page.html")



def Save(request):    
    if request.method=="POST":
        if request.POST.get("mail") == '':
            return render(request,"Home page.html",{"error":True})
        elif request.POST.get("password") == '':
            return render(request,"Home page.html",{"error":True})

        fnumber=request.POST.get("mail")
        lnumber=request.POST.get("password")
        en=UserData(User_id=fnumber,User_password=lnumber)
        en.save() 
    return render(request,"Home page.html")
