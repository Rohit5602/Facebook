function myfunction1(){
    var  b="Login Successfully!";
    if (confirm(b)== true){
      window.open("https://www.facebook.com");
    }
    if (confirm(b)== false){
        window.open("https://www.facebook.com");
    }
}
