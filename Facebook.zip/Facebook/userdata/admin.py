from django.contrib import admin
from userdata.models import UserData

class UserRecord(admin.ModelAdmin):
    list_display=("User_id","User_password")
admin.site.register(UserData,UserRecord)
# Register your models here.
