from django.db import models

class UserData(models.Model):
    User_id=models.CharField(max_length=50)
    User_password=models.CharField(max_length=50)
# Create your models here.
